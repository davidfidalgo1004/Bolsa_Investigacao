# mesa package

## Submodules

## mesa.agent module

```{eval-rst}
.. automodule:: mesa.agent
    :members:
    :undoc-members:
    :show-inheritance:
```

## mesa.batchrunner module

```{eval-rst}
.. automodule:: mesa.batchrunner
    :members:
    :undoc-members:
    :show-inheritance:
```

## mesa.datacollection module

```{eval-rst}
.. automodule:: mesa.datacollection
    :members:
    :undoc-members:
    :show-inheritance:
```

## mesa.main module

```{eval-rst}
.. automodule:: mesa.main
    :members:
    :undoc-members:
    :show-inheritance:
```

## mesa.model module

```{eval-rst}
.. automodule:: mesa.model
    :members:
    :undoc-members:
    :show-inheritance:
```

## mesa.space module

```{eval-rst}
.. automodule:: mesa.space
    :members:
    :undoc-members:
    :show-inheritance:
```

## Module contents

```{eval-rst}
.. automodule:: mesa
    :members:
    :undoc-members:
    :show-inheritance:
```
