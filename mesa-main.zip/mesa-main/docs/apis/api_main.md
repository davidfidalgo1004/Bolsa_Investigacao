# APIs

```{toctree}
:maxdepth: 3

model
agent
time
space
datacollection
batchrunner
visualization
logging
experimental
```
