# Model

```{eval-rst}
.. automodule:: mesa.model
   :members:
   :inherited-members:
```
