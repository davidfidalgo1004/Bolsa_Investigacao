# Agent


```{eval-rst}
.. automodule:: mesa.agent
   :members:
   :inherited-members:
```
